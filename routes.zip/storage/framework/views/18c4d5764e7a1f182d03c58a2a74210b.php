<?php $__env->startSection('name', 'Service | ' . $service->name); ?>
<?php $__env->startSection('content'); ?>
<main class="bg-black">
    <div class="font-sans" style="background-image: url('<?php echo e(asset('img/logoWKM.jpg')); ?>'); background-size: 70%; background-repeat: no-repeat; background-position: center; background-attachment: fixed;">
        
        <div class="bg-black bg-opacity-75 py-5 px-4 d-flex align-items-center min-vh-100">
            
            <div class="container">
                
                <div class="bg-light bg-opacity-95 rounded-3 shadow-lg p-4 p-md-5">
                    
                    <nav aria-label="breadcrumb" class="mb-4">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('service')); ?>" class="text-decoration-none" style="color: #000000;">Services</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($service->name); ?></li>
                        </ol>
                    </nav>
                    
                    <h1 class="display-4 fw-bold mb-4 text-dark"><?php echo e($service->name); ?></h1>
                    
                    <div class="row g-5">
                        
                        <?php if(!empty($service->image)): ?>
                        <div class="col-lg-6">
                            <img src="<?php echo e(asset($service->image)); ?>" alt="<?php echo e($service->name); ?>" class="img-fluid rounded-3 shadow-lg">
                        </div>
                        <?php endif; ?>

                        <div class="<?php if(!empty($service->image)): ?> col-lg-6 <?php else: ?> col-12 <?php endif; ?>">
                            <h2 class="fw-bold mb-4 text-dark">Service Overview</h2>
                            <p class="lead fw-normal">
                                <?php echo nl2br(e($service->description)); ?>

                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/service_detail.blade.php ENDPATH**/ ?>