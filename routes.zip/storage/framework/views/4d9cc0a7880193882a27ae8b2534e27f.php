<?php $__env->startSection('name', 'Product'); ?>
<?php $__env->startSection('content'); ?>
<main class="product-main-background" style="background-image: url('<?php echo e(asset('img/logoWKM.jpg')); ?>'); background-size: 70%;">
    <div class="product-bg-overlay py-5">
        <div class="container-xl py-5">
            <h1 class="display-4 fw-bold text-center mb-5 text-white">Our Innovative <span class="text-gold">Products & Solutions</span></h1>
            
            <?php $__empty_1 = true; $__currentLoopData = $product_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand_name => $products_in_brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mb-5">
                <h2 class="display-5 fw-bold text-center mb-5 text-white"><?php echo e($brand_name); ?></h2>
                
                <?php
                    $brandSlug = Str::slug($brand_name);
                ?>

                <div class="row row-cols-1 row-cols-lg-2 g-4">
                    <?php $__currentLoopData = $products_in_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col product-item <?php echo e($loop->iteration > 10 ? 'd-none' : ''); ?>" data-brand="<?php echo e($brandSlug); ?>">
                            <a href="<?php echo e(route('product.detail', ['id' => $item->id])); ?>" class="text-decoration-none h-100 d-block">
                                <div class="card bg-custom-card-dark text-white h-100 shadow-lg custom-card">
                                    <div class="row g-0 h-100">
                                        <div class="col-md-7">
                                            <div class="card-body d-flex flex-column">
                                                <p class="card-text text-white-50 mb-2"><?php echo e($item->category->name ?? 'Uncategorized'); ?></p>
                                                <h3 class="card-title h4 fw-bold mb-2 text-gold"><?php echo e($item->name); ?></h3>
                                                <p class="card-text small"><?php echo e(Str::limit($item->description, 120)); ?></p>
                                            </div>
                                        </div>
                                        <div class="col-md-5 d-flex align-items-center p-3">
                                            <img src="<?php echo e(asset('storage/' . $item->image) ?? 'https://placehold.co/600x400/212529/FFFFFF?text=No+Image'); ?>" class="img-fluid rounded product-card-img" alt="<?php echo e($item->name); ?>">
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if($products_in_brand->count() > 10): ?>
                    <div class="text-center mt-4">
                        <button class="btn btn-custom fw-bold text-nowrap show-more-btn" data-brand="<?php echo e($brandSlug); ?>">
                            Show More
                        </button>
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center text-white bg-dark p-5 rounded-3">
                <p class="lead">No products are currently listed. Please check back later.</p>
            </div>
            <?php endif; ?>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/product.blade.php ENDPATH**/ ?>