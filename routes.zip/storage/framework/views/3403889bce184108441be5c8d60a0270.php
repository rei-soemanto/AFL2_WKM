<nav class="navbar navbar-dark navbar-custom">
    <div class="container-fluid d-flex flex-nowrap align-items-center justify-content-between">

        <!-- Logo -->
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('img/logoWKM.png')); ?>" alt="WKM Logo" class="navbar-logo">
        </a>

        <!-- Nav links (MD - XL) -->
        <ul class="navbar-nav d-none fw-bold d-md-flex flex-row align-items-center">
            <li class="nav-item mx-1"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li class="nav-item mx-1"><a class="nav-link" href="<?php echo e(route('admin.users.list')); ?>">User</a></li>
            <li class="nav-item mx-1"><a class="nav-link" href="<?php echo e(route('admin.projects.list')); ?>">Portfolio</a></li>
            <li class="nav-item mx-1"><a class="nav-link" href="<?php echo e(route('admin.products.list')); ?>">Products</a></li>
            <li class="nav-item mx-1"><a class="nav-link" href="<?php echo e(route('admin.services.list')); ?>">Services</a></li>
        </ul>

        <?php if(auth()->guard()->check()): ?>
            <div class="nav-item dropdown mx-2 mx-lg-2">
                <a class="nav-link dropdown-toggle fw-bold" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="font-size: 24px; color: #e0bb35;">
                    Admin, <?php echo e(Auth::user()->name); ?>

                </a>
                <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end" aria-labelledby="navbarDropdown">

                    <li><a class="dropdown-item" href="<?php echo e(url('/')); ?>">User View</a></li>

                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                    this.closest('form').submit();">
                                <?php echo e(('Log Out')); ?>

                            </a>
                        </form>
                    </li>
                </ul>
            </div>
        <?php endif; ?>
    </div>

    <!-- Line and button (XS - SM) -->
    <div class="w-100 d-md-none">
        <hr class="custom-divider mt-0"> 
        
        <div class="text-center py-2">
            <button class="btn btn-link custom-arrow-toggle" 
                    type="button" 
                    data-bs-toggle="collapse" 
                    data-bs-target="#navLinksCollapse" 
                    aria-expanded="false" 
                    aria-controls="navLinksCollapse">
                    <i class="bi bi-caret-down-fill"></i>
                </button>
        </div>
    </div>

    <div class="collapse navbar-collapse d-md-none" id="navLinksCollapse">
        <div class="container-fluid">
            <ul class="navbar-nav 
                    flex-column flex-sm-row 
                    align-items-center justify-content-center 
                    mb-0 mx-auto w-100 custom-nav-xs">
                <li class="nav-item mx-sm-1 py-2">
                    <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                </li>
                <li class="nav-item mx-sm-1 py-2">
                    <a class="nav-link" href="<?php echo e(route('admin.users.list')); ?>">User</a>
                </li>
                <li class="nav-item mx-sm-1 py-2">
                    <Portfolio class="nav-link" href="<?php echo e(route('admin.projects.list')); ?>">Portfolio</a>
                </li>
                <li class="nav-item mx-sm-1 py-2">
                    <a class="nav-link" href="<?php echo e(route('admin.products.list')); ?>">Products</a>
                </li>
                <li class="nav-item mx-sm-1 py-2">
                    <a class="nav-link" href="<?php echo e(route('admin.services.list')); ?>">Services</a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/layout/admin_nav.blade.php ENDPATH**/ ?>