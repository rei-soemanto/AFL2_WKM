<div class="copyright">
    <div class="container-fluid">
        <p class="text-center text-white-50 pb-4 footer-copyright mb-0">© 2025 Wraksa Kencana Mukti. All rights reserved.</p>
    </div>
</div><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/layout/admin_footer.blade.php ENDPATH**/ ?>