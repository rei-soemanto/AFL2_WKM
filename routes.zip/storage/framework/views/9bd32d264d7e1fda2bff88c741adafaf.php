<?php $__env->startSection('name', 'Project'); ?>
<?php $__env->startSection('content'); ?>
<main class="project-main-background" style="background-image: url('<?php echo e(asset('img/logoWKM.jpg')); ?>'); background-size: 70%;">
    <div class="project-bg-overlay py-5">
        <div class="container-xl py-5">
            <h1 class="display-4 fw-bold text-center mb-5 text-white">Our <span class="text-gold">Projects</span></h1>
            
            <?php $__empty_1 = true; $__currentLoopData = $project_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_name => $projects_in_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $carouselId = Str::slug($category_name);
                ?>
                <div class="mb-5">
                    <h2 class="display-5 fw-bold text-center mb-5 text-white"><?php echo e($category_name); ?></h2>
                    
                    <?php if(count($projects_in_category) > 1): ?>
                        <div id="<?php echo e($carouselId); ?>" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php $__currentLoopData = $projects_in_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                        <a href="/project/<?php echo e($item['project_id']); ?>" class="text-decoration-none">
                                            <div class="bg-custom-card-dark rounded-3 shadow-lg p-5">
                                                <div class="row align-items-center g-5">
                                                    <div class="col-md-6">
                                                        <img src="<?php echo e(asset('storage/' . $item['image']) ?? 'https://placehold.co/...'); ?>" alt="<?php echo e($item['name']); ?>" class="img-fluid rounded-3 project-card-img">
                                                    </div>
                                                    <div class="col-md-6 text-white">
                                                        <h3 class="h2 fw-bold mb-3 text-gold"><?php echo e($item['name']); ?></h3>
                                                        <p class="text-white-50"><?php echo e(Str::limit($item['description'], 200)); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#<?php echo e($carouselId); ?>" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#<?php echo e($carouselId); ?>" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>

                    <?php else: ?>
                        <?php $item = $projects_in_category[0]; ?>
                        <a href="/project/<?php echo e($item['project_id']); ?>" class="text-decoration-none">
                            <div class="bg-custom-card-dark rounded-3 shadow-lg p-5">
                                <div class="row align-items-center g-5">
                                    <div class="col-md-6">
                                        <img src="<?php echo e($item['image'] ?? 'https://placehold.co/600x400/212529/FFFFFF?text=No+Image'); ?>" alt="<?php echo e($item['name']); ?>" class="img-fluid rounded-3 project-card-img">
                                    </div>
                                    <div class="col-md-6 text-white">
                                        <h3 class="h2 fw-bold mb-3 text-gold"><?php echo e($item['name']); ?></h3>
                                        <p class="text-white-50"><?php echo e(Str::limit($item['description'], 200)); ?></p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center text-white bg-dark p-5 rounded-3">
                    <p class="lead">No projects are currently listed. Please check back later.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/project.blade.php ENDPATH**/ ?>