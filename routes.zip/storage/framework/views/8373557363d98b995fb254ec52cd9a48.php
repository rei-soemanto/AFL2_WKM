<?php $__env->startSection('name', 'Service'); ?>
<?php $__env->startSection('content'); ?>
<main class="service-main-background" style="background-image: url('<?php echo e(asset('img/aboutpagebg.jpg')); ?>')">
    <div class="service-bg-overlay py-5">
        <div class="container-xl py-5">
            <h1 class="display-4 fw-bold text-center mb-5 text-white">Our Expert <span class="text-gold">Services</span></h1>
            
            <div class="d-grid gap-5">
                <?php $__empty_1 = true; $__currentLoopData = $service_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card shadow-lg card-translucent p-4 p-md-5">
                        <div class="card-body">
                            <h2 class="display-5 fw-bold mb-2"><?php echo e($category_data['category_name']); ?></h2>
                            <p class="lead text-secondary mb-5"><?php echo e($category_data['category_description']); ?></p>
                            
                            <div class="row row-cols-1 row-cols-md-2 g-4">
                                <?php $__currentLoopData = $category_data['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col">
                                    <a href="<?php echo e(route('service.detail', ['id' => $service['id']])); ?>" class="text-decoration-none">
                                        <div class="service-item h-100 custom-card-mouseover">
                                            <h3 class="h5 fw-bold" style="color: #0f0f0f;"><?php echo e($service['name']); ?></h3>
                                            <p class="mb-0 text-secondary"><?php echo e(Str::limit($service['description'], 120)); ?></p>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-white bg-dark p-5 rounded-3">
                        <p class="lead">No services are currently listed. Please check back later.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/service.blade.php ENDPATH**/ ?>