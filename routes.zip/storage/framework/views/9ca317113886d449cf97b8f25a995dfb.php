

<?php $__env->startSection('name', 'Manage Users'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-background" style="background-image: url('<?php echo e(asset('img/aboutpagebg.jpg')); ?>')">
    <div class="bg-overlay min-vh-100 py-5">
        <div class="container-xl py-5">
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="display-5 fw-bold text-white">User Interests</h1>
            </div>

            <?php if(session('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card card-translucent shadow-lg">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col" class="p-3">User Name</th>
                                <th scope="col" class="p-3">Email</th>
                                <th scope="col" class="p-3">Interested Products</th>
                                <th scope="col" class="p-3">Interested Services</th>
                                <th scope="col" class="p-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="p-3 fw-bold"><?php echo e($user->name); ?></td>
                                    <td class="p-3 text-secondary"><?php echo e($user->email); ?></td>
                                    <td class="p-3">
                                        <?php if($user->interested_products->count() > 0): ?>
                                            <ul class="list-unstyled mb-0 small">
                                                <?php $__currentLoopData = $user->interested_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($product->name); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php else: ?>
                                            <span class="text-secondary small">None</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3">
                                        <?php if($user->interested_services->count() > 0): ?>
                                            <ul class="list-unstyled mb-0 small">
                                                <?php $__currentLoopData = $user->interested_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($service->name); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php else: ?>
                                            <span class="text-secondary small">None</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3 text-center text-nowrap">
                                        <a href="mailto:<?php echo e($user->email); ?>" class="btn btn-primary btn-sm fw-semibold">Contact</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center p-5 text-secondary">No users found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/admin/manage_user.blade.php ENDPATH**/ ?>