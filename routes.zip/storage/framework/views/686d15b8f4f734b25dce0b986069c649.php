<?php $__env->startSection('name', 'Project | ' . $project->name); ?>
<?php $__env->startSection('content'); ?>
<main class="font-sans" style="background-image: url('<?php echo e(asset('img/aboutpagebg.jpg')); ?>'); background-size: cover; background-repeat: no-repeat; background-position: center; background-attachment: fixed;">
    
    <div class="bg-black bg-opacity-75 py-5 px-4 min-vh-100 d-flex align-items-center">
        
        <div class="container">

            <div class="bg-light bg-opacity-95 rounded-3 shadow-lg p-4 p-md-5">
                
                <nav aria-label="breadcrumb" class="mb-4">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('project')); ?>" class="text-decoration-none" style="color: #000000;">Projects</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($project->name); ?></li>
                    </ol>
                </nav>
                
                <h1 class="display-4 fw-bold mb-2 text-dark"><?php echo e($project->name); ?></h1>
                <p class="fs-5 text-muted fw-semibold mb-4"><?php echo e($project->category_names); ?></p>
                
                <div class="row g-5">
                    
                    <div class="col-lg-6">
                        <?php if($project_images->isNotEmpty()): ?>
                            <div id="projectImageCarousel" class="carousel slide shadow-lg rounded" data-bs-ride="carousel">
                                
                                <?php if($project_images->count() > 1): ?>
                                    <div class="carousel-indicators">
                                        <?php $__currentLoopData = $project_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <button type="button" data-bs-target="#projectImageCarousel" data-bs-slide-to="<?php echo e($key); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>" aria-current="<?php echo e($loop->first ? 'true' : 'false'); ?>" aria-label="Slide <?php echo e($key + 1); ?>"></button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>

                                <div class="carousel-inner rounded">
                                    <?php $__currentLoopData = $project_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                                            <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>" class="d-block w-100" style="aspect-ratio: 4/3; object-fit: cover;" alt="<?php echo e($project->name); ?>">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <?php if($project_images->count() > 1): ?>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#projectImageCarousel" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#projectImageCarousel" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <img src="https://placehold.co/600x400/CCCCCC/FFFFFF?text=No+Image" alt="No Image Available" class="img-fluid rounded-3 shadow-lg">
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-6">
                        <h2 class="fw-bold mb-4 text-dark">Project Overview</h2>
                        <div class="lead fw-normal">
                            <?php echo nl2br(e($project->description)); ?>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/project_detail.blade.php ENDPATH**/ ?>