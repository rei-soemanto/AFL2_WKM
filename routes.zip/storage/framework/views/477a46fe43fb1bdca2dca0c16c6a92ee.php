

<?php $__env->startSection('name', 'Page Not Found'); ?>
<?php $__env->startSection('content'); ?>
<main class="bg-black">
    <div class="hero-container d-flex flex-column">
        <div class="bg-overlay-darker flex-grow-1 d-flex align-items-center justify-content-center text-center">
            
            <div>
                <h1 class="display-huge fw-bolder text-gold">404</h1>
                <p class="h2 fw-bold text-white mt-4">Page Not Found</p>
                
                <p class="text-white-50 mt-4">Sorry, the page you are looking for does not exist or has been moved.</p>
                
                <div class="mt-5">
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-gold btn-lg fw-bold">
                        Go Back Home
                    </a>
                </div>
            </div>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rei Soemanto\Herd\afl2_wkm\resources\views/errors/404.blade.php ENDPATH**/ ?>